---
name: Rift Vanguard Tactical HUD
colors:
  surface: '#111417'
  surface-dim: '#111417'
  surface-bright: '#37393d'
  surface-container-lowest: '#0c0e12'
  surface-container-low: '#191c1f'
  surface-container: '#1d2023'
  surface-container-high: '#282a2e'
  surface-container-highest: '#323539'
  on-surface: '#e1e2e7'
  on-surface-variant: '#bbc9c9'
  inverse-surface: '#e1e2e7'
  inverse-on-surface: '#2e3134'
  outline: '#859393'
  outline-variant: '#3c4949'
  surface-tint: '#4cdade'
  primary: '#63ecf0'
  on-primary: '#003738'
  primary-container: '#3fd0d4'
  on-primary-container: '#005557'
  inverse-primary: '#00696c'
  secondary: '#4ddea7'
  on-secondary: '#003826'
  secondary-container: '#00a576'
  on-secondary-container: '#003120'
  tertiary: '#ffd387'
  on-tertiary: '#422c00'
  tertiary-container: '#e6b65f'
  on-tertiary-container: '#664700'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ff6fa'
  primary-fixed-dim: '#4cdade'
  on-primary-fixed: '#002021'
  on-primary-fixed-variant: '#004f51'
  secondary-fixed: '#6efbc2'
  secondary-fixed-dim: '#4ddea7'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#005138'
  tertiary-fixed: '#ffdea9'
  tertiary-fixed-dim: '#f0bf66'
  on-tertiary-fixed: '#271900'
  on-tertiary-fixed-variant: '#5e4100'
  background: '#111417'
  on-background: '#e1e2e7'
  surface-variant: '#323539'
typography:
  headline-lg:
    fontFamily: Space Mono
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: 0.15em
  headline-lg-mobile:
    fontFamily: Space Mono
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: 0.12em
  headline-md:
    fontFamily: Space Mono
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: 0.1em
  headline-sm:
    fontFamily: Space Mono
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: 0.08em
  body-lg:
    fontFamily: JetBrains Mono
    fontSize: 15px
    fontWeight: '500'
    lineHeight: 22px
    letterSpacing: 0.02em
  body-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.12em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.14em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 9px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.18em
spacing:
  gutter: 0.75rem
  gutter-desktop: 1rem
  margin: 0.75rem
  margin-desktop: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system delivers a high-density, mission-critical tactical interface built for deep space planetary defense and orbital mech command. Blending retro-terminal telemetry with military-grade avionics HUD aesthetics, it prioritizes diagnostic legibility, spatial urgency, and unyielding mechanical precision. 

The aesthetic is purely functionalist and structural: hard 90-degree edges, razor-sharp 1px seams, technical readouts, telemetry grids, and phosphor-reactive glows. The emotional resonance is high-stakes command—austere, calculated, and urgent. Visual noise is rejected in favor of dense tabular metrics, indexed component identifiers (e.g., `// SYS_01`, `[SEC-REC]`), and scanline-punctuated data arrays.

## Colors

The palette operates under a high-contrast tactical night-vision doctrine:
- **Base Canvas (`#05070A`)**: Void black base absorbing all ambient spill.
- **Panel Surface (`#0A1018`)**: Deep obsidian-slate tint for telemetry housings and modular deck cards.
- **Panel Borders & Structural Seams (`#16222F`)**: 1px structural framing grid providing physical separation of modules.
- **Primary Cyber Cyan (`#3FD0D4`)**: Primary active HUD focus, targeting crosshairs, telemetry gauges, and critical telemetry streams.
- **Status Green (`#46D9A2`)**: Core integrity, stable reactor telemetry, shields nominal, secure telemetry locks.
- **Amber Warning (`#E3B35C`)**: Thermal dissipation limits, proximity warnings, non-critical sub-system degradation.
- **Hazard Red (`#FF6B5E`)**: Hull breach, critical core overload, hostile lock-on, mission abort triggers.
- **Muted Telemetry (`#52697F`)**: Tertiary labels, coordinate offsets, inactive track lines, and unit indicators.

## Typography

Typography functions as instrumentation. Every glyph belongs to a monospaced family to ensure strict tabular alignment of floating coordinate variables, dynamic countdown timers, and core status matrices.

- **Headers & Display:** Set in uppercase `Space Mono` with expanded tracking (`0.08em` to `0.15em`). Always preceded by terminal decorators (e.g., `> // SYS_CONFIG`, `[SECTOR 04]`).
- **Body & Data Streams:** Set in `JetBrains Mono` for maximum distinction between zero (`0`), capital `O`, and numeric delimiters.
- **Labels & Micro-data:** Strict uppercase tracking for HUD callouts, sub-tier telemetry, status codes, and input legends.

## Layout & Spacing

The layout is an uncompromising technical deck grid. It utilizes a fluid multi-column matrix inspired by avionics instrumentation panels, designed to eliminate dead space while avoiding claustrophobia through precise 1px wire separation.

- **Desktop Form Factor:** 12-column or 16-column continuous telemetry deck with fixed lateral diagnostic sidebars (280px–360px wide) flanking an adaptive central tactical viewport.
- **Mobile / Tactical Datapad Form Factor:** Vertical tactical stack, collapsing secondary metrics into tabbed sub-decks or collapsible terminal drawers.
- **Rhythm:** Spacing follows a compact 4px baseline rhythm (`space-xs: 4px`, `space-sm: 8px`, `space-md: 12px`, `space-lg: 20px`, `space-xl: 32px`). Density takes precedence over expansive whitespace to keep maximum operational state visible without scrolling.

## Elevation & Depth

Tactile physical layering and diffuse drop shadows are strictly prohibited. Depth is rendered via phosphor luminosity, border occlusion, and flat planar z-indexing:

- **Surface Housing (Z0):** Flat `#0A1018` surfaces bound by a crisp, continuous 1px `#16222F` border.
- **Scanline Overlays:** Panels incorporate subtle horizontal CSS micro-scanlines (`repeating-linear-gradient(0deg, rgba(0,0,0,0.2) 0px, rgba(0,0,0,0.2) 1px, transparent 1px, transparent 2px)`) at 20% opacity.
- **Phosphor Bloom (Active Focus):** High-priority or active alert containers project a crisp inner wireframe highlight (`box-shadow: inset 0 0 0 1px #3FD0D4`) combined with a faint, tight outer phosphor bloom (`0 0 8px rgba(63, 208, 212, 0.25)`).
- **Hazard Overlays:** Critical warnings pulse a 1px border between `#16222F` and `#FF6B5E` without geometric displacement.

## Shapes

The geometric doctrine is zero-radius: strictly `0px` curvature. No pill buttons, soft bubbles, or rounded container envelopes are permitted. 

Angular chamfers (45-degree clipped corners via `clip-path: polygon(...)`) are reserved for primary tactical triggers, radar scopes, and header module badges to emphasize mechanized combat hardware. All card partitions, diagnostic graphs, and interactive inputs terminate at sharp 90-degree right angles.

## Components

### Buttons & Actuators
- **Primary Command:** Sharp 1px `#3FD0D4` border, `#0A1018` background, `#3FD0D4` uppercase text with `label-lg` typography. Active/Hover state: background fills entirely with `#3FD0D4`, text turns `#05070A` with zero transition lag (instant mechanical response). Corner notches (`4px` 45-degree chamfer top-right).
- **Hazard / Emergency Dump:** Sharp 1px `#FF6B5E` border, `#FF6B5E` text. Diagonal warning hazard stripes on hover (`repeating-linear-gradient(45deg, rgba(255,107,94,0.15), rgba(255,107,94,0.15) 6px, transparent 6px, transparent 12px)`).
- **Sub-system Toggle:** Monospace block button with an indexed state indicator `[ OFF ]` / `[ ON ]`.

### Chips & Tactical Badges
- Modular telemetry chips formatted as bracketed tags: `[ READY ]`, `[ FAULT // SEC-08 ]`.
- Background: `#05070A`, border: 1px solid corresponding status color (`#46D9A2`, `#E3B35C`, or `#FF6B5E`), text sized at `label-sm`.

### Input Fields & Data Terminals
- Framed by 1px `#16222F` borders with an active state snapping to `#3FD0D4`.
- Accompanied by fixed technical pre-prompts (e.g., `SYS:// ` or `ORD_ID > `).
- Caret is a solid blinking block (`█`) in `#3FD0D4` at 1Hz frequency.

### Cards & Telemetry Housings
- Background `#0A1018`, border 1px `#16222F`.
- Header bar includes a structural technical tag strip: left-aligned section title with sub-code (e.g., `MODULE: POWER_GRID // 04-A`), right-aligned auxiliary status indicator dot (`4px` square).
- Optional reticle crosshairs (`+`) rendered in `#52697F` at the top-left and bottom-right container intersections.

### Checkboxes & Toggle Switches
- **Checkboxes:** Rigid `14px x 14px` square with a 1px border. Checked state displays a solid inner `8px x 8px` square or crisp diagonal `X` in `#3FD0D4`.
- **Radio Selectors:** Sharp diamond shapes (`rotate(45deg)`) with a central active diamond pip. Never use rounded circles.

### Specialized Telemetry Displays
- **Segmented Bar Gauges:** Core health, shield, and heat monitors structured as discrete, non-blended, segmented ticks (e.g., 20 vertical bars with 1px gaps), shifting dynamically from `#46D9A2` through `#E3B35C` to `#FF6B5E`.